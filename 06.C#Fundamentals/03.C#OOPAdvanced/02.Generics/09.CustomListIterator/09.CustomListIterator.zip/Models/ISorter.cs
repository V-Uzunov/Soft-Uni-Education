﻿namespace _08.CustomListSorter.Models
{
    public interface ISorter<T>
    {
        void Sort();
    }
}
