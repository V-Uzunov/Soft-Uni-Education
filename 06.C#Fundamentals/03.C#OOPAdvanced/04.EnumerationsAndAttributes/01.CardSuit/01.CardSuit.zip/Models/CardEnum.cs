﻿namespace _01.CardSuit.Models
{
    public enum CardEnum
    {
        Clubs,
        Diamonds,
        Hearts,        
        Spades
    }
}
