﻿namespace _03.CardPower.Models
{
    public enum CardSuitEnum
    {
        Clubs,
        Diamonds = 13,
        Hearts = 26,
        Spades = 39
    }
}
