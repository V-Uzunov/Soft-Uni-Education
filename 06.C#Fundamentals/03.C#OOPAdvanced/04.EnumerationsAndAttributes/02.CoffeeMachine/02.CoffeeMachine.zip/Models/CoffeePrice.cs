﻿public enum CoffeePrice
{
    None=0,
    Small = 50,
    Normal = 100,
    Double = 200
}