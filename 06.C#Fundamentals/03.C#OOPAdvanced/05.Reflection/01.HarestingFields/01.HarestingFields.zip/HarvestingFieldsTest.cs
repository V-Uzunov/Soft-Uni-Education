﻿namespace _01HarestingFields
{
    using Models;

    public class HarvestingFieldsTest
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
