﻿public class Assassin : AbstractHero
{
    private const int StrengthPointsCreate = 25;
    private const int AgilityPointsCreate = 100;
    private const int IntelligencePointsCreate = 15;
    private const int HitPointsCreate = 150;
    private const int DamagePointsCreate = 300;


    public Assassin(string name, int strength, int agility, int intelligence, int hitPoints, int damage, IInventory inventory) : base(name, strength, agility, intelligence, hitPoints, damage, inventory)
    {
        this.Agility = AgilityPointsCreate;
        this.Strength = StrengthPointsCreate;
        this.Intelligence = IntelligencePointsCreate;
        this.HitPoints = HitPointsCreate;
        this.Damage = DamagePointsCreate;
    }
}