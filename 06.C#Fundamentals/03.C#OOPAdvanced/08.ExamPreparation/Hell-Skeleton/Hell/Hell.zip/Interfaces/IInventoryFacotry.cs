﻿public interface IInventoryFacotry
{
}