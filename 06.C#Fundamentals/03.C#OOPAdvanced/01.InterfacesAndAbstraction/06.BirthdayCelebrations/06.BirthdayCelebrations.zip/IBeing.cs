﻿namespace _06.BirthdayCelebrations
{
    public interface IBeing
    {
        string Id { get; }
    }
}
