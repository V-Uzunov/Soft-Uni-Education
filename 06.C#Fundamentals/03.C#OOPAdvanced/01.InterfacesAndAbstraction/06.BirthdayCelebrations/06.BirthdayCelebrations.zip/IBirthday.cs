﻿namespace _06.BirthdayCelebrations
{
    public interface IBirthday
    {
        string Name { get; }
        string Birthday { get; }
    }
}
