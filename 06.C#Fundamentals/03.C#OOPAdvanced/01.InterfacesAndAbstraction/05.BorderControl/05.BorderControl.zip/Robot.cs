﻿namespace _05.BorderControl
{
    using System;
    using System.Security.Permissions;
    using System.Text;

    public class Robot : IBoearder
    {
        public Robot(string model, string id)
        {
            this.Model = model;
            this.Id = id;
        }
        public string Model { get; private set; }
        public string Id { get; private set; }
        
    }
}
