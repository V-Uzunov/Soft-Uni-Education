﻿namespace _05.BorderControl
{
    public interface IBoearder
    {
        string Id { get; }
    }
}
