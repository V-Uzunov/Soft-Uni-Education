﻿namespace _07.FoodShortage.Interfaces
{
    public interface IBirthable
    {
        string Birthday { get; }
    }
}
