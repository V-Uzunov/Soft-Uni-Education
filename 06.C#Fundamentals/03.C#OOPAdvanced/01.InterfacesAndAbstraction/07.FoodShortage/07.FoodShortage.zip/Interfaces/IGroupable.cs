﻿namespace _07.FoodShortage.Interfaces
{
    public interface IGroupable
    {
        string Group { get; }
    }
}
