﻿namespace _07.FoodShortage.Interfaces
{
    public interface IAgeing
    {
        string Age { get; }
    }
}
