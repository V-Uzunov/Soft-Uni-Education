﻿namespace _07.FoodShortage.Interfaces
{
    interface IPerson : INameble, IBuyer, IAgeing
    {

    }
}
