﻿namespace _07.FoodShortage.Interfaces
{
    public interface INameble
    {
        string Name { get; }
    }
}
