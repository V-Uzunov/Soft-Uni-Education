﻿namespace _03.Ferrari
{
    public class Ferrari : Car
    {
        public Ferrari(string driver) : base(driver)
        {
        }
    }
}
