﻿namespace _01.DefineAnInterfaceIPerson
{
    public interface IPerson
    {
        string Name { get; }
        int Age { get; }
    }
}
