﻿namespace _01.DefineAnInterfaceIPerson
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
