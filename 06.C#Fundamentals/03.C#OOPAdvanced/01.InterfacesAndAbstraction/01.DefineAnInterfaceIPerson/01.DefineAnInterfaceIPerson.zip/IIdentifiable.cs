﻿namespace _01.DefineAnInterfaceIPerson
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
