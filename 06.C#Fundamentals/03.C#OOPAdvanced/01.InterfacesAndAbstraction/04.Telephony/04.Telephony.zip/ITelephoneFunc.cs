﻿namespace _04.Telephony
{
    public interface ITelephoneFunc
    {
        string Calling(string number);
        string Browsing(string url);
    }
}
