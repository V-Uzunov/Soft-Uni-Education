﻿public interface IWriter
{
    void Write();
    void Write(string element);
}