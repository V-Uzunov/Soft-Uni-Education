﻿public interface IReader
{
    string Read();
}