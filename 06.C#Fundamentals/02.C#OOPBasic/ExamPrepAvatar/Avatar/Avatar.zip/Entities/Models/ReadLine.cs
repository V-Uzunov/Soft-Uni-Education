﻿using System;

public class ReadLine : IReader
{
    public string Read()
    {
        return Console.ReadLine();
    }
}
