﻿public interface IBender
{
    string Name { get; }
    int Power { get; }
    double GetTotalPower();
}