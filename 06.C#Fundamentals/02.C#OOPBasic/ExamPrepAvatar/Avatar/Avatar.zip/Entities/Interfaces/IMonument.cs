﻿public interface IMonument
{
    string Name { get; }
    double GetMonumentBonus();
}
