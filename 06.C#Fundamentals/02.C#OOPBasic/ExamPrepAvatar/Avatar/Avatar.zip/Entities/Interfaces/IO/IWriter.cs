﻿public interface IWriter
{
    void Write();

    void Write(params string[] element);
}