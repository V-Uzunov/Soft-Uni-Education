﻿public class Startup
{
    public static void Main()
    {
        var puppy = new Puppy();

        puppy.Eat();
        puppy.Bark();
        puppy.Weep();
    }
}

