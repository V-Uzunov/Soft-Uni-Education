﻿using System;

public class Dog : Animal
{
    public void Eat()
    {
        Console.WriteLine("eating...");
    }
}

