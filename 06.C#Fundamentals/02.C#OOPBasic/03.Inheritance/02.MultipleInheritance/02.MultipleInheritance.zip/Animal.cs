﻿using System;

public class Animal
{
    public void Bark()
    {
        Console.WriteLine("barking...");
    }
}

