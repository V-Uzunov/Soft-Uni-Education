﻿
public class Startup
{
    public static void Main()
    {
        var dog = new Dog();
        dog.Eat();
        dog.Bark();
    }
}

